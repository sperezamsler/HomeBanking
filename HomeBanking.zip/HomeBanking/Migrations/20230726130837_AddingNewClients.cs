﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HomeBanking.Migrations
{
    public partial class AddingNewClients : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
