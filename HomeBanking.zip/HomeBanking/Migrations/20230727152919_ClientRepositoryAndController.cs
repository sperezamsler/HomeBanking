﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HomeBanking.Migrations
{
    public partial class ClientRepositoryAndController : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
