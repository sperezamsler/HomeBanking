﻿namespace HomeBanking.Models
{
    public enum CardType
    {
        CREDIT,
        DEBIT
    }
}
