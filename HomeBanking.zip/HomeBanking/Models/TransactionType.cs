﻿
namespace HomeBanking.Models
{
    public enum TransactionType
    {
        CREDIT,
        DEBIT
    }
}
