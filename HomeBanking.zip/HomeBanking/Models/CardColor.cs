﻿namespace HomeBanking.Models
{
    public enum CardColor
    {
        GOLD,
        SILVER,
        TITANIUM
    }
}
